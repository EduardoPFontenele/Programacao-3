public class Fibonacci{
    public static void main(String[] args) {

        int a = 1;
        int b = 1;

        System.out.println("--- FIBONACCI ---\n");

        System.out.println(a);
        System.out.println(b);

        // OBS: Laço vai até 28 pois os dois primeiros termos da sequência ja foram impressos
        for (int i = 0; i < 28; i++) {

            int c =  a + b;
            System.out.println(c);

            a = b;
            b = c;
        }

    }

}

